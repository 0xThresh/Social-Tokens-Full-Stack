# -*- coding: utf-8 -*-
from .multiaddr import Multiaddr  # NOQA

__author__ = 'Steven Buss'
__email__ = 'steven.buss@gmail.com'
__version__ = '0.0.9'
