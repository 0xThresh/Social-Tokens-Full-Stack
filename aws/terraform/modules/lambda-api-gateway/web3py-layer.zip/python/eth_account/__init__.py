from eth_account.account import (
    Account,
)

__all__ = ["Account"]
